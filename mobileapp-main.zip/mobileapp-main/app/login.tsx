
import LoginScreen from '@/LoginScreen'

const login = () => {
  return <LoginScreen/>
}

export default login

