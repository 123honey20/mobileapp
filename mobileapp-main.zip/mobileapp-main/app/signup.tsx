
import SignupScreen from '@/SignupScreen'

const signup = () => {
  return <SignupScreen/>
}

export default signup

